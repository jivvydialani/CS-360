package com.zybooks.weighttrackingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;

public class NotificationSettings extends AppCompatActivity {


    Button deleteAccount;
    UserDatabase userDB;
    WeightDatabase weightDB;
    User user;
    CompoundButton button;
    EditText phone;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification_settings);

        user = User.getUserInstance();
        phone = findViewById(R.id.enterPhoneNumber);
        phone.setText(user.getText());

        deleteAccount = findViewById(R.id.deleteAccountButton);
        button = findViewById(R.id.notifications);
        button.setChecked(user.isNotificationPermission());
        button.setOnCheckedChangeListener((buttonView, isChecked) -> user.setNotificationPermission(isChecked));

    }

    public void deleteUserAccount(View view) {
        userDB = UserDatabase.getInstance(this);
        weightDB = WeightDatabase.getInstance(this);
        user = User.getUserInstance();

        weightDB.deleteUser(user);
        userDB.deleteUser(user);

        this.finishAffinity();
        System.exit(0);
    }

    public void openMain(View view) {

        phone = findViewById(R.id.enterPhoneNumber);
        String mPhone = phone.getText().toString();

        user.setText(mPhone);

        Intent intent = new Intent(this, Dashboard.class);
        startActivity(intent);
    }
}