package com.zybooks.weighttrackingapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText mUsername;
    EditText mPassword;
    Button mLoginButton;
    TextView mPasswordMessage;
    UserDatabase userDB;
    User registeredUser;
    WeightDatabase weightDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mUsername = findViewById(R.id.usernameInput);
        mPassword = findViewById(R.id.passwordInput);
        mLoginButton = findViewById(R.id.loginButton);
        mPasswordMessage = findViewById(R.id.passwordMessage);

        userDB =  UserDatabase.getInstance(this);

        mLoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = mUsername.getText().toString();
                String password = mPassword.getText().toString();

                boolean userGood = userDB.verifyUsername(username);
                boolean passGood = userDB.verifyPassword(username, password);

                if (userGood){
                    if (passGood) {
                        Toast.makeText(MainActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                        loginSuccessful(view, username);
                    } else {
                        Toast.makeText(MainActivity.this, "Password incorrect", Toast.LENGTH_SHORT).show();
                    }
                } else if(!userGood) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                    builder
                            .setTitle("Account not found")
                            .setMessage("Create an account?")
                            .setIcon(android.R.drawable.ic_dialog_alert)
                            .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    Boolean userAdded = userDB.addUser(username, password);

                                    if(userAdded) {
                                        Toast.makeText(MainActivity.this, "Account registered!", Toast.LENGTH_SHORT).show();
                                    } else {
                                        Toast.makeText(MainActivity.this, "Account registration unsuccessful", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            })
                            .setNegativeButton("No", null)
                            .show();
                }
            }
        });

        mPassword.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() <= 4) {
                    mPasswordMessage.setVisibility(View.VISIBLE);
                    mLoginButton.setEnabled(false);
                } else {
                    mPasswordMessage.setVisibility(View.INVISIBLE);
                    mLoginButton.setEnabled(true);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

    }

    private void loginSuccessful(View view, String mUser) {

        //initialize the weights database
        weightDB = WeightDatabase.getInstance(this);

        //initialize the UserModel
        registeredUser = User.getUserInstance();
        registeredUser.setUsername(mUser);
        registeredUser.setGoalWeight(weightDB.getGoalWeight(registeredUser));

        Intent intent = new Intent(this, Dashboard.class);
        startActivity(intent);
    }
}
