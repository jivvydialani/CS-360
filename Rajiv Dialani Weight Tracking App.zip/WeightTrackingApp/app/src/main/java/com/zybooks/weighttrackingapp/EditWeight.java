package com.zybooks.weighttrackingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

public class EditWeight extends AppCompatActivity {

    WeightDatabase weightDB;
    User user;

    // List to hold check rows
    List<CompoundButton> checkedRows = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_weight);

        try {
            onInit();
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }
    public void addWeightForm(View view){
        Intent intent = new Intent(this, EditWeight.class);
        startActivity(intent);
    }

    public void openDash(View view){
        Intent intent = new Intent(this, Dashboard.class);
        startActivity(intent);
    }

    public void onInit() throws ParseException {
        weightDB = WeightDatabase.getInstance(this);
        user = User.getUserInstance();

        List<WeightClass> allEntries = new ArrayList<>();
        allEntries = weightDB.getAllWeight(user);

        TableLayout table = findViewById(R.id.editTable);

        //Header
        TableRow header = new TableRow(this);

        TextView header1 = new TextView(this);
        header1.setText(R.string.selection);
        header1.setBackgroundResource(R.color.white);
        header1.setGravity(Gravity.CENTER);
        header1.setPadding(10,10,10,10);
        header.addView(header1);

        TextView header2 = new TextView(this);
        header2.setText(R.string.column1);
        header2.setBackgroundResource(R.color.white);
        header2.setGravity(Gravity.CENTER);
        header2.setPadding(10,10,10,10);
        header.addView(header2);

        TextView header3 = new TextView(this);
        header3.setText(R.string.column2);
        header3.setBackgroundResource(R.color.white);
        header3.setGravity(Gravity.CENTER);
        header3.setPadding(10,10,10,10);
        header.addView(header3);

        table.addView(header);

        for (int i = 0; i < allEntries.size(); i++){
            TableRow row = new TableRow(this);

            CheckBox check = new CheckBox(this);
            check.setGravity(Gravity.CENTER);
            check.setPadding(10,10,10,10);
            check.setId(allEntries.get(i).getId());

            TableRow.LayoutParams rowParams = new TableRow.LayoutParams();
            rowParams.gravity = Gravity.CENTER;
            rowParams.span = 1;
            check.setLayoutParams(rowParams);

            check.setOnClickListener(new View.OnClickListener(){

                @Override
                public void onClick(View v) {
                    int mId = ((CompoundButton) v).getId();
                    String sID = String.valueOf(mId);

                    if(((CompoundButton) v).isChecked()){
                        checkedRows.add((CompoundButton) v);
                    } else {
                        checkedRows.remove((CompoundButton) v);
                    }
                }
            });

            row.addView(check);

            TextView text1 = new TextView(this);
            text1.setText(allEntries.get(i).getDate());
            text1.setTextSize(14);
            text1.setBackgroundResource(R.color.white);
            text1.setGravity(Gravity.CENTER_HORIZONTAL);
            text1.setPadding(10,10,10,10);
            row.addView(text1);

            TextView text2 = new TextView(this);
            text2.setText(String.valueOf(allEntries.get(i).getWeight()));
            text2.setTextSize(14);
            text2.setBackgroundResource(R.color.white);
            text2.setGravity(Gravity.CENTER_HORIZONTAL);
            text2.setPadding(10,10,10,10);
            row.addView(text2);

            table.addView(row);
        }
    }

    public void deleteRow(View view){

        for(CompoundButton a : checkedRows){
            weightDB.removeEntry(a.getId());
        }

        finish();
        overridePendingTransition(0, 0);
        startActivity(getIntent());
        overridePendingTransition(0, 0);
    }

}