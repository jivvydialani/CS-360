package com.zybooks.weighttrackingapp;

public class User {
    private String username;
    private float goalWeight = 0;
    private boolean notificationPermission = false;
    private String text;
    private static User mValidUser;

    //Checks for single user
    public static User getUserInstance() {
        if (mValidUser == null) {
            mValidUser = new User();
        }
        return mValidUser;
    }

    //Constructor
    private User(){}

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public float getGoalWeight() {
        return goalWeight;
    }

    public void setGoalWeight(float goalWeight) {
        this.goalWeight = goalWeight;
    }

    public boolean isNotificationPermission() {
        return notificationPermission;
    }

    public void setNotificationPermission(boolean notificationPermission) {
        this.notificationPermission = notificationPermission;
    }

    public String getText(){
        return text;
    }

    public void setText(String text){
        this.text = text;
    }
}
