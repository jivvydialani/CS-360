package com.zybooks.weighttrackingapp;

import android.telephony.SmsManager;

import java.util.ArrayList;

public class TextNotification {
    public static void sendText(String phoneNumber) {
        String message = "Congratulations! You've reached your goal weight!";
        SmsManager manager = SmsManager.getDefault();
        ArrayList<String> parts = manager.divideMessage(message);
        manager.sendMultipartTextMessage(phoneNumber, null, parts, null, null);
    }
}
