package com.zybooks.weighttrackingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;

import java.util.Calendar;

public class EnterWeight extends AppCompatActivity {

    protected EditText mDate;
    protected EditText mWeight;
    protected String isoDate;
    User mUser;
    WeightDatabase weightDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_weight);

        mDate = findViewById(R.id.editWeightDate);
        mWeight = findViewById(R.id.editWeight);

        mUser = User.getUserInstance();
        weightDB = WeightDatabase.getInstance(this);

        mDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get instance of Calendar
                final Calendar c = Calendar.getInstance();

                int year = c.get(Calendar.YEAR);
                int month = c.get(Calendar.MONTH);
                int day = c.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog = new DatePickerDialog(
                        EnterWeight.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {

                                mDate.setText((monthOfYear + 1) + "-" + dayOfMonth + "-" + year);
                                isoDate = String.valueOf(year) + "-" + String.valueOf(monthOfYear + 1) + "-" +
                                        String.valueOf(dayOfMonth);
                            }
                        },
                        year, month, day);

                datePickerDialog.show();
            }

        });
    }

    public void openMainForm(View view) {
        Intent intent = new Intent(this, Dashboard.class);
        startActivity(intent);
    }

    public void onSaveClick(View view) {
        String date = mDate.getText().toString();
        String sWeight = mWeight.getText().toString();
        float weight = 0;

        // Check for empty form
        if (!date.equals("") && !sWeight.equals("")) {
            weight = Float.valueOf(sWeight);
            WeightClass entry = new WeightClass(isoDate, weight);
            Boolean weightAdd = weightDB.addEntry(entry, mUser);

            // If user has set and notification turned on, send message
            if (weight <= mUser.getGoalWeight()) {
                if (mUser.isNotificationPermission()) {
                    TextNotification.sendText(mUser.getText());
                }
            }
        }

        // Back to Dashboard screen
        Intent intent = new Intent(this, Dashboard.class);
        startActivity(intent);

    }
}
