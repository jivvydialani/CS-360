package com.zybooks.weighttrackingapp;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class WeightDatabase extends SQLiteOpenHelper {
    private static final int version = 1;
    private static final String databaseName = "weights.db";
    private static WeightDatabase mWeightDB;

    public WeightDatabase(@Nullable Context context) {
        super(context, databaseName, null, version);
    }

    public static WeightDatabase getInstance(Context context) {
        if (mWeightDB == null) {
            mWeightDB = new WeightDatabase(context);
        }

        return mWeightDB;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create Table weights(_ID INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, date text, weight float)");

        db.execSQL("create Table goals(username TEXT primary key, goal float)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop Table if exists weights");
        db.execSQL("drop Table if exists goals");
    }

    public Boolean addEntry(WeightClass entry, User user) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put("username", user.getUsername());
        values.put("date", entry.getDate());
        values.put("weight", entry.getWeight());

        long id = db.insert("weights", null, values);

        return id == 1;
    }

    public void removeEntry(Integer weightEntry) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("weights", "_id = ?", new String[] {String.valueOf(weightEntry)});
    }

    public boolean updateEntry(int id, float weight, User user) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put("username", user.getUsername());
        values.put("weight", weight);

        long mId = db.update("weights", values, "id = " + id, null);

        return mId == 1;
    }

    public void addGoal(User user) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put("username", user.getUsername());
        values.put("goal", user.getGoalWeight());

        boolean isGoalSet = false;
        long id = 0;

        String query = "Select * from goals";
        @SuppressLint("Recycle") Cursor cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst()) {
            do {
                String username = cursor.getString(0);
                if (username.equals(user.getUsername())) {
                    isGoalSet = true;
                    break;
                }
            } while (cursor.moveToNext());
        }

        if (!isGoalSet) {
            id = db.insert("goals", null, values);
        }
        else {
            id = db.updateWithOnConflict("goals", values, "username = ?",
                    new String[] {user.getUsername()}, SQLiteDatabase.CONFLICT_REPLACE);
        }
    }

    @SuppressLint("Recycle")
    public float getGoalWeight(User registeredUser) {
        SQLiteDatabase db = this.getWritableDatabase();


        float setGoal = 0;

        String query = "Select * from goals";
        Cursor cursor = db.rawQuery(query, null);

        if(cursor.moveToFirst()) {
            do {
                String username = cursor.getString(0);

                if(username.equals(registeredUser.getUsername())) {
                    setGoal = cursor.getFloat(1);
                    break;
                }
            } while (cursor.moveToNext());
        }

        return setGoal;
    }

    @SuppressLint("SimpleDateFormat")
    public List<WeightClass> getAllWeight(User user) throws ParseException {
        List<WeightClass> weightEntries = new ArrayList<>();
        SQLiteDatabase db = this.getWritableDatabase();
        @SuppressLint("Recycle") Cursor cursor = db.rawQuery("SELECT * FROM weights ORDER BY date", null);

        if (cursor.moveToFirst()){
            do {
                // Get username
                String username = cursor.getString(1);

                // Check if username matches
                if (username.equals(user.getUsername())){
                    int id = cursor.getInt(0);
                    String date = cursor.getString(2);

                    // Change date format
                    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
                    Date newDate = null;
                    String niceDate = null;

                    try {
                        newDate = format.parse(date);
                        format = new SimpleDateFormat("MM-dd-yyyy");
                        assert newDate != null;
                        niceDate = format.format(newDate);
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }

                    int userWeight = cursor.getInt(3);

                    WeightClass newEntry = new WeightClass(id, niceDate, userWeight);
                    weightEntries.add(newEntry);
                }
            } while (cursor.moveToNext());
        }
        cursor.close();
        return weightEntries;
    }

    public void deleteUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();

        db.delete("goals", "username = ?", new String[]{user.getUsername()});
        db.delete("weights", "username = ?", new String[]{user.getUsername()});
    }
}
