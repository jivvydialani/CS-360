package com.zybooks.weighttrackingapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

public class Dashboard extends AppCompatActivity {

    Button editButton;
    WeightDatabase db;
    User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        editButton = findViewById(R.id.editWeightButton);

        try {
            onInit();
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    private void onInit() throws ParseException {
        db = WeightDatabase.getInstance(this);
        user = User.getUserInstance();

        List<WeightClass> weightEntries = new ArrayList<>();
        weightEntries = db.getAllWeight(user);

        TableLayout table = findViewById(R.id.weight_table);
        TableRow header = new TableRow(this);

        TextView header1 = new TextView(this);
        header1.setText(R.string.column1);
        header1.setBackgroundResource(R.color.white);
        header1.setGravity(Gravity.CENTER);
        header1.setPadding(10, 10, 10, 10);
        header.addView(header1);

        TextView header2 = new TextView(this);
        header2.setText(R.string.column2);
        header2.setBackgroundResource(R.color.white);
        header2.setGravity(Gravity.CENTER);
        header2.setPadding(10, 10, 10, 10);
        header.addView(header2);

        TextView header3 = new TextView(this);
        header3.setText(R.string.column3);
        header3.setBackgroundResource(R.color.white);
        header3.setGravity(Gravity.CENTER);
        header3.setPadding(10, 10, 10, 10);
        header.addView(header3);

        table.addView(header);

        for (int i = 0; i < weightEntries.size(); i++) {
            TableRow row = new TableRow(this);
            TextView text1 = new TextView(this);
            text1.setText(weightEntries.get(i).getDate());
            text1.setTextSize(14);
            text1.setBackgroundResource(R.color.white);
            text1.setGravity(Gravity.CENTER_HORIZONTAL);
            text1.setPadding(10, 10, 10, 10);
            row.addView(text1);

            TextView text2 = new TextView(this);
            text2.setText(String.valueOf(weightEntries.get(i).getWeight()));
            text2.setTextSize(14);
            text2.setBackgroundResource(R.color.white);
            text2.setGravity(Gravity.CENTER_HORIZONTAL);
            text2.setPadding(10, 10, 10, 10);
            row.addView(text2);

            TextView text3 = new TextView(this);
            float weightRemaining = weightEntries.get(i).getWeight() - user.getGoalWeight();
            String stringWeightRemaining = String.valueOf(weightRemaining);

            text3.setText(stringWeightRemaining);
            text3.setTextSize(14);
            text3.setBackgroundResource(R.color.white);
            text3.setGravity(Gravity.CENTER_HORIZONTAL);
            text3.setPadding(10, 10, 10, 10);
            row.addView(text3);

            table.addView(row);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.notification_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        openSettings();
        return false;
    }

    public void openSettings(){
        Intent intent = new Intent(this, NotificationSettings.class);
        startActivity(intent);
    }

    public void openEditWeight(View view){
        Intent intent = new Intent(this, EditWeight.class);
        startActivity(intent);
    }

    public void addWeightForm(View view){
        Intent intent = new Intent(this, EnterWeight.class);
        startActivity(intent);
    }

    public void newGoal(View view){
        User user  = User.getUserInstance();
        WeightDatabase db = WeightDatabase.getInstance(this);

        AlertDialog.Builder builder = new AlertDialog.Builder(Dashboard.this);
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_CLASS_NUMBER);

        builder
                .setView(input)
                .setTitle("Enter Goal Weight")
                .setMessage("Change your current goal of " + user.getGoalWeight() + "?")
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @SuppressLint("UnsafeIntentLaunch")
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        float goalWeight = Float.parseFloat(input.getText().toString());
                        user.setGoalWeight(goalWeight);
                        db.addGoal(user);
                        user.setGoalWeight(goalWeight);

                        finish();
                        overridePendingTransition(0,0);
                        startActivity(getIntent());
                        overridePendingTransition(0,0);
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

}

